Euro Truck Simulator 2 / American Truck Simulator - Indian Radio Channels

Created by : ziberArc-GameMods
          _ __              ___             
   ____  (_) /_  ___  _____/   |  __________ ©
  /_  / / / __ \/ _ \/ ___/ /| | / ___/ ___/
   / /_/ / /_/ /  __/ /  / ___ |/ /  / /__  
  /___/_/_.___/\___/_/  /_/  |_/_/   \___/  
                                           ᴳᵃᵐᵉ ᴹᵒᵈˢ
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Supported for all ETS2 & ATS versions.
 
Installation Guide
01. Extract the "ETS2-ATS-Indian-Radio-Channels.zip" file.
02. Select your State/location folder.
03. Copy the "live_streams.sii" and paste it to the "Documents\Euro Truck Simulator 2" or "Documents\American Truck Simulator" folder.
⚠️ Keep a backup of the existing "live_streams.sii" file in the folder.

* "All Mega Pack" Folder includes all states radio channels.
⚠️ Don't Change anything in these files. It may be not working.

Have Fun...
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


States:
	1. Andhra Pradesh
	2. Chandigarh
	3. Chhattisgarh
	4. Gujarat
	5. Haryana
	6. Jharkhand
	7. Karnataka
	8. Kerala
	9. Madhya Pradesh
	10.Maharashtra
	11.National Capital Territory of Delhi
	12.Odisha
	13.Punjab
	14.Rajasthan
	15.Tamil Nadu
	16.Uttar Pradesh
	17.West Bengal

Channels:
	1.  Ajmer Radio
	2.  AR RADIO
	3.  ASR DIGITAL RADIO
	4.  AURAL MELODICS
	5.  Aural Radio
	6.  Aural West
	7.  Ave Geetham Tamil Radio
	8.  BBC Hindi
	9.  BBC World Service
	10. Beam FM
	11. Beam FM - Adult Hits
	12. Bhakti World - Ganesha
	13. Bol Punjabi Radio
	14. Bollywood Gaane Purane
	15. Bollywood Punjabi
	16. Bollywood Punjabi Radio
	17. Boxout.fm
	18. Capital Disko
	19. CJM Ministries
	20. CrypticU Radio
	21. Desi Radio Hits
	22. DiscoBani Kolkata | Bengali Hits
	23. Dukh Niwaran Sahib
	24. E Malayalam - EMG Radio Station
	25. Eawaz 770 AM
	26. Ephphatha Radio Malayalam
	27. Farz Uloom Radio - Urdu 
	28. FM Kottarakara
	29. FnF.FM
	30. Folk Nama | Bengali Folk Songs
	31. Go Yesteryears | Ever Green Bengali Songs
	32. Gurbani Kirtan
	33. Hindi Bible Radio
	34. Hindi Desi Bollywood Evergreen Hits
	35. Hindi Desi Bollywood Evergreen Hits - Channel 2
	36. Hindi Desi Bollywood Evergreen Hits - Channel 3
	37. IBC Tamil
	38. Inbam FM Radio
	39. India Sings
	40. Isai Thentral Tamil Radio
	41. JehovahRapha FM
	42. Jesus Alive Radio
	43. JOEL FM
	44. JOichen's Radio-Malayalam Hindi Tamil Hits Live News
	45. Josh FM
	46. Joyful Melodies Radio
	47. Kalasam FM
	48. Kalighat Radio
	49. Kerala Malabar Islamic Radio
	50. Khamma Gani Rajasthan
	51. Khristiya Jagriti Radio
	52. Konkani Christian Radio
	53. Latest IR
	54. Luminous Radio
	55. Madani Muzakra Radio - Urdu
	56. Madhur Sangeet
	57. Maippanin Kural Tamil Radio
	58. Marudhara Radio
	59. Marwar Radio
	60. Mohabbat Radio
	61. Mono Phone | BongOnet
	62. My Selfie Redio
	63. MyIndMedia
	64. New Hits Of Bollywood
	65. Niche Radio
	66. Njan Malayalee Bhakti
	67. NP 24 Radio
	68. NWGELC Korba Radio
	69. NWGELCDG Live
	70. Odia Radio
	71. Old Monk Radio
	72. OZion FM
	73. Paadu Nilavae Tamil Radio
	74. Periyava Vanoli
	75. PoeTree FoRest Station
	76. Pollachi FM
	77. Psalms Radio
	78. Quran Radio - Urdu
	79. Radio AmchiKONKANI
	80. Radio Baingan
	81. Radio Bangla Rock | BongOnet
	82. Radio Bhubaneswar
	83. Radio BongOnet
	84. Radio DC 90.4 FM
	85. Radio Dhaakad
	86. Radio Gethu
	87. Radio Green
	88. Radio Hindi International
	89. Radio Mangalam 91.2
	90. Radio Media Village
	91. Radio Onattukara
	92. Radio Panj
	93. Radio Rajputana
	94. Radio Sharda
	95. Radio Tirur
	96. Radio Vatakara
	97. Radio Virsa
	98. Radio Voxa
	99. Radio Zhakkas
	100.Rainbow FM KOCHI 107.5
	101.Rajasthani Bhajan
	102.Rak 103.5 FM
	103.Rangilo Gujarat
	104.Retro Bollywood
	105.Revive Radio
	106.Robichhaya | Rabindra Sangeet Radio
	107.Sai Global Harmony
	108.Sakkath Radio
	109.Sarthak FM 91.9
	110.Sayaji FM
	111.Schizoid - Chillout
	112.Schizoid - Psychedelic Trance
	113.Sehion Radio
	114.Sri Chinmoy 1
	115.Sri Chinmoy 2
	116.Sri Chinmoy 3
	117.Sri Chinmoy 4
	118.Sri Chinmoy 5
	119.Sri Ramana - Voice of Arunachala
	120.SS Tamil Radio
	121.Suvarthamaanam Online Radio
	122.Suvarthamaanam Telugu Online Christian Radio online
	123.Tamil Kuyil Radio
	124.Tamil Movie Radio
	125.Tamil Panpalai Gold
	126.Tamil Radio
	127.TCR Live
	128.Telugu Bible Radio
	129.Thedal FM
	130.Thowheed FM
	131.Vismaya Kerala Malayalam Internet Radio
	132.VoiceOfTrumpetRadio
	133.Wisdom Radio
	134.Zindagi Forever Radio

----------------------------------------------------------
🚦 ziberArc-GameMods	:https://is.gd/ziberArc_GameMods
🚦 Youtube		:https://www.youtube.com/channel/UCPZLz4RHFlCRzyIthekMX5Q
🚦 Steam community	:https://steamcommunity.com/id/ziberarc/screenshots/
🚦 World of Trucks	:https://www.worldoftrucks.com/en/profile/5852561
🚦 ModLand		:https://www.modland.net/user/ziberarc
💬 Contact		:ziberarc@gmail.com
🎮 Facebook		:https://www.facebook.com/Ziber-Arc-104862328216254
----------------------------------------------------------
𝘻𝘪𝘣𝘦𝘳𝘈𝘳𝘤-𝘎𝘢𝘮𝘦 𝘔𝘰𝘥𝘴 - 𝘙𝘦𝘶𝘱𝘭𝘰𝘢𝘥𝘪𝘯𝘨 𝘪𝘴 𝘴𝘵𝘳𝘪𝘤𝘵𝘭𝘺 𝘱𝘳𝘰𝘩𝘪𝘣𝘪𝘵𝘦𝘥©.